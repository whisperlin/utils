{

	"metadata" :
	{
		"formatVersion" : 3.1,
		"generatedBy"   : "Blender 2.65 Exporter",
		"vertices"      : 4,
		"faces"         : 1,
		"normals"       : 0,
		"colors"        : 0,
		"uvs"           : [],
		"materials"     : 0,
		"morphTargets"  : 0,
		"bones"         : 0
	},

	"scale" : 1.000000,

	"materials" : [],

	"vertices" : [-1,-1,0, -1,1,0, 1,1,0 ,1,-1,0],

	"morphTargets" : [],

	"normals" : [],

	"colors" : [],

	"uvs" : [[]],

	"faces" : [1,3,2,1,0],

	"bones" : [],

	"skinIndices" : [],

	"skinWeights" : [],

	"animation" : {}


}
