var searchData=
[
  ['edgestocollapse',['edgesToCollapse',['../class_krabl_mesh_1_1_simplify_parameters.html#ad68f6d80c42378f6444b8d0a60f36d32',1,'KrablMesh::SimplifyParameters']]]
];
