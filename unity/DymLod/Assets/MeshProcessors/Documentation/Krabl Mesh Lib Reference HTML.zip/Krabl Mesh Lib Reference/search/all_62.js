var searchData=
[
  ['boneweightprotection',['boneWeightProtection',['../class_krabl_mesh_1_1_simplify_parameters.html#a3509db61d6d2c37d89a45ba090cde364',1,'KrablMesh::SimplifyParameters']]],
  ['borderweight',['borderWeight',['../class_krabl_mesh_1_1_simplify_parameters.html#afba1d9933d12d05b2a7a8fdbb77f9cd8',1,'KrablMesh::SimplifyParameters']]]
];
