var searchData=
[
  ['preventnonmanifoldedges',['preventNonManifoldEdges',['../class_krabl_mesh_1_1_simplify_parameters.html#a51a86a34ef33b9dcb6210e3a42ee1b30',1,'KrablMesh::SimplifyParameters']]]
];
