var searchData=
[
  ['tristoquads',['TrisToQuads',['../class_krabl_mesh_1_1_ops.html#a6895d106280099efb100daf86a7cc82c',1,'KrablMesh::Ops']]]
];
