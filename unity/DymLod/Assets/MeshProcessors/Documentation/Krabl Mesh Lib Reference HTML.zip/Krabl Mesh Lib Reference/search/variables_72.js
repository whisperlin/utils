var searchData=
[
  ['recalculatenormals',['recalculateNormals',['../class_krabl_mesh_1_1_subdivide_q_parameters.html#a30a41f56f8cd7566cbd7200fe8d8445f',1,'KrablMesh::SubdivideQParameters']]],
  ['recalculatevertexpositions',['recalculateVertexPositions',['../class_krabl_mesh_1_1_simplify_parameters.html#a7a77ac1ca50e3887877bc7f783543321',1,'KrablMesh::SimplifyParameters']]]
];
