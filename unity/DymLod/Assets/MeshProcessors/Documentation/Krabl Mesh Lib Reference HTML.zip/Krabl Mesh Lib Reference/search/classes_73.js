var searchData=
[
  ['simplify',['Simplify',['../class_krabl_mesh_1_1_simplify.html',1,'KrablMesh']]],
  ['simplifyparameters',['SimplifyParameters',['../class_krabl_mesh_1_1_simplify_parameters.html',1,'KrablMesh']]],
  ['subdivideq',['SubdivideQ',['../class_krabl_mesh_1_1_subdivide_q.html',1,'KrablMesh']]],
  ['subdivideqparameters',['SubdivideQParameters',['../class_krabl_mesh_1_1_subdivide_q_parameters.html',1,'KrablMesh']]]
];
