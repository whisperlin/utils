var searchData=
[
  ['checktopology',['checkTopology',['../class_krabl_mesh_1_1_simplify_parameters.html#a57b4ec771fe608788b11e9ccfa232d71',1,'KrablMesh::SimplifyParameters']]],
  ['creaseweight',['creaseWeight',['../class_krabl_mesh_1_1_simplify_parameters.html#ae985281b47dbb6a5e2c10d57eeebdb89',1,'KrablMesh::SimplifyParameters']]]
];
