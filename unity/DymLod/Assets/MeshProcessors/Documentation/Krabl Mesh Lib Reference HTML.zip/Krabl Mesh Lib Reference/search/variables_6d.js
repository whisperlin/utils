var searchData=
[
  ['materialseamweight',['materialSeamWeight',['../class_krabl_mesh_1_1_simplify_parameters.html#afac2e2a3e9cb8ebb1279a17c284cad99',1,'KrablMesh::SimplifyParameters']]],
  ['maxedgespervertex',['maxEdgesPerVertex',['../class_krabl_mesh_1_1_simplify_parameters.html#ad59ef807b0150e3229d18e942ef1a3dc',1,'KrablMesh::SimplifyParameters']]],
  ['maximumerror',['maximumError',['../class_krabl_mesh_1_1_simplify_parameters.html#a9ace761f4a5f860c7ccb0ab4173e3b8b',1,'KrablMesh::SimplifyParameters']]]
];
