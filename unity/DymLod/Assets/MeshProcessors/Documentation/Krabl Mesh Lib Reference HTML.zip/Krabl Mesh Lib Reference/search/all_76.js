var searchData=
[
  ['vertexcolorprotection',['vertexColorProtection',['../class_krabl_mesh_1_1_simplify_parameters.html#ac92b186cb482fd0db73fd35b3b4e5965',1,'KrablMesh::SimplifyParameters']]]
];
